def display_menu():
    print("""
    MENU:
    1. OSH - 25 000 SOM
    2. MANTI - 15 000 SOM
    3. LAGMON - 20 000 SOM
    4. SHASHLIK - 10 000 SOM
    """)



zakazlar = {}





