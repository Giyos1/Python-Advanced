# from constant import summa, zakazlar


def calculate_total(summa, zakazlar):
    total = 0
    total += summa
    print("ZAKAZLARINGIZ -", zakazlar)
    print("SIZNI TOTAL BUYURTMANGIZ NARXI -", total)
