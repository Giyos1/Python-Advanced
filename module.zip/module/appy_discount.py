# from constant import summa


def apply_discount(summa):
    j = input("PROMOKOD KIRITASIZMI: ha/ yoq: ")
    if j == 'ha' or j == 'HA':
        promokod = input("PROMOKODNI KIRITING: ")
        if promokod == 'uz24':
            print("PROMOKOD QABUL QILINDI, 30 FOYZ CHEGIRMA")
            pn = summa / 10
            pn *= 3
            total = summa - pn
            print("TOTAL, CHEGIRMA BILAN -", total)
