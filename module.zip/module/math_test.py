# import math
#
# print(math.floor(13.99))
# # print(int(13.99999))
# print(math.fabs(-12))

# from datetime import datetime
#
# a = datetime(2024, 2, 2, 12, 12, 3, 3)
# b = datetime.now()
# print((b - a))
# print(a.year - b.year)
# # print(b.minute)
# def factorial(n):
#     if n == 0:
#         return 1
#     return n * factorial(n - 1)
#
#
# print(factorial(5))

# a = "salom"
#
#
# def reverse_a(a):
#     if len(a) == 0:
#         return ""
#     else:
#         return a[-1] + reverse_a(a[:-1])
#
#
# print(reverse_a(a))

# summa(8)  # 1+2+3+4+5+6+7+8
# def summa(n):
#     if n == 0:
#         return 0
#     return n + summa(n - 1)  # 6+5+4+3+2+1+0


# summa(5) 5+summa(4_

# print(summa(6))
def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n - 1)


print(factorial(5))
